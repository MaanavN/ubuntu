#!/bin/bash
/startpulse.sh &
/usr/bin/mate-session > /dev/null 2>&1
